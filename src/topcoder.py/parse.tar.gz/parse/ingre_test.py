#!/usr/bin/env python
#coding=utf8

'''
Created on Oct 17, 2016

@author: Chauncey
'''

try:
    import sys
    import rsa
    import os
    import urllib
    import urllib2
    import cookielib
    import base64
    import re
    import hashlib
    import json
    import binascii
    import time
    import datetime
    import threading
    from bs4 import BeautifulSoup
    import nltk
    import operator
    import math

except ImportError:
        print >> sys.stderr, """\

There was a problem importing one of the Python modules required.
The error leading to this problem was:

%s

Please install a package which provides this module, or
verify that the module is installed correctly.

It's possible that the above module doesn't match the current version of Python,
which is:

%s

""" % (sys.exc_info(), sys.version)
        sys.exit(1)


__prog__= "parse"
__version__="0.1 beta"

def handle_lianjia(url):
    try:
        #url = 'http://bj.lianjia.com/fangjia/' #+str(i)
        html = urllib2.urlopen(url).read()
        #html = '<div class="intro clear" mod-id="lj-common-bread"><div class="container">hi</div></div>'
        soup = BeautifulSoup(html, "html.parser")

        block = soup.find("div", attrs={"class": "box-l"})
        avg_price = block.find("span", id="monthTrans")
        if avg_price and avg_price.string:
            avg_price = avg_price.string
        else:
            avg_price = "-"

        variation_div = block.find("div", class_="qushi-1")
        variation = variation_div.find_all("span")
        pat_compare = re.compile(u'(\d+\.\d+%)', re.M)
        match_month = pat_compare.search(variation[1].string)
        if match_month:
            compare_month = match_month.group(1)
        else:
            compare_month = '-'
        match_year = pat_compare.search(variation[2].string)
        if match_year:
            compare_year = match_year.group(1)
        else:
            compare_year = '-'

        bottom_div = block.find("div", class_="box-l-b")
        nums = bottom_div.find_all("div", class_="num")
        str_nums = ''
        for num in nums:
            str_nums += num.span.string + "\t"
        #ratio_cp = nums[0].string
        #contract_yesterday = nums[1].string
        #views = nums[2].string

        nearday = block.find("div", class_="qushi-2").find_all("a", class_="txt")
        pat_insale = re.compile(u'在售房源(\d+)套', re.M)
        match_insale = pat_insale.search(nearday[0].string)
        if match_insale:
            insale = match_insale.group(1)
        else:
            insale = '-'

        pat_contract = re.compile(u'成交房源(\d+)套', re.M)
        match_contract = pat_contract.search(nearday[1].string)
        if match_contract:
            contract = match_contract.group(1)
        else:
            contract = '-'

        #print "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n" %(ratio_cp, contract_yesterday, views, insale, contract, avg_price, compare_month, compare_year)
        return "%s%s\t%s\t%s\t%s\t%s\n" %(str_nums, insale, contract, avg_price, compare_month, compare_year)
    except Exception:
        traceback_template = '''Traceback (most recent call last):
             File "%(filename)s", line %(lineno)s, in %(name)s
             %(type)s: %(message)s\n'''
        exc_type, exc_value, exc_traceback = sys.exc_info()
        traceback_details = {
                'filename': exc_traceback.tb_frame.f_code.co_filename,
                'lineno' : exc_traceback.tb_lineno,
                'name'  : exc_traceback.tb_frame.f_code.co_name,
                'type'  : exc_type.__name__,
                'message' : exc_value.message, # or see traceback._some_str()
                }
        print traceback_template % traceback_details
        #print sys.exc_info()
        time.sleep(1.0)
        return handle_lianjia(url)


def handle_wangqian(url):
    try:
        #url = 'http://bj.lianjia.com/fangjia/' #+str(i)
        html = urllib2.urlopen(url).read()
        #html = '<div class="intro clear" mod-id="lj-common-bread"><div class="container">hi</div></div>'
        soup = BeautifulSoup(html, "html.parser")

        tables = soup.find_all("table", attrs={"class": "tjInfo"})
        block = tables[2]
        rows = block.find_all("tr")
        pattern = re.compile(u'(.+)存量房网上签约', re.M)
        match_date = pattern.search(rows[0].string)
        if match_date:
            date = match_date.group(1)
        else:
            date = '-'

        str_nums = ''
        for row in rows[1:]:
            str_nums += '\t' + row.find("td").string
        #print "%s%s" %(date, str_nums)
        return "%s%s\n" %(date, str_nums)
    except Exception:
        traceback_template = '''Traceback (most recent call last):
             File "%(filename)s", line %(lineno)s, in %(name)s
             %(type)s: %(message)s\n'''
        exc_type, exc_value, exc_traceback = sys.exc_info()
        traceback_details = {
                'filename': exc_traceback.tb_frame.f_code.co_filename,
                'lineno' : exc_traceback.tb_lineno,
                'name'  : exc_traceback.tb_frame.f_code.co_name,
                'type'  : exc_type.__name__,
                'message' : exc_value.message, # or see traceback._some_str()
                }
        print traceback_template % traceback_details
        #print sys.exc_info()
        time.sleep(1.0)
        return handle_wangqian(url)

cities = {'北京': 'http://bj.lianjia.com/fangjia/'}

departments = {'铭科苑': 'http://bj.lianjia.com/fangjia/c1111027378318/',
        '智学苑': 'http://bj.lianjia.com/fangjia/c1111027382721/',
        '天通苑中苑': 'http://bj.lianjia.com/fangjia/c1111027380057/',
        '天通苑东二区': 'http://bj.lianjia.com/fangjia/c1111027380049/',
        '天通苑东三区': 'http://bj.lianjia.com/fangjia/c1111027380050/',
        '天通苑东一区': 'http://bj.lianjia.com/fangjia/c1111027380051/',
        '天通西苑三区': 'http://bj.lianjia.com/fangjia/c1111027380054/',
        '天通西苑二区': 'http://bj.lianjia.com/fangjia/c1111027380053/',
        '天通西苑一区': 'http://bj.lianjia.com/fangjia/c1111027380055/',
        '天通苑本四区': 'http://bj.lianjia.com/fangjia/c1111027380045/',
        '天通苑北三区': 'http://bj.lianjia.com/fangjia/c1111027380043/',
        '天通苑北二区': 'http://bj.lianjia.com/fangjia/c1111027380040/',
        '天通苑北一区': 'http://bj.lianjia.com/fangjia/c1111027380047/',
        '政泰家园': 'http://bj.lianjia.com/fangjia/c1111027382663/',
        '东辰小区': 'http://bj.lianjia.com/fangjia/c1111027376788/',
        '佳运园一期': 'http://bj.lianjia.com/fangjia/c1111027377557/',
        '佳运园二期': 'http://bj.lianjia.com/fangjia/c1111027377553/',
        '佳运园三期': 'http://bj.lianjia.com/fangjia/c1111027377555/',
        '北苑家园望春园': 'http://bj.lianjia.com/fangjia/c1111027376257/',
        '北苑家园茉藜园': 'http://bj.lianjia.com/fangjia/c1111027376255/',
        '北苑家园清友园': 'http://bj.lianjia.com/fangjia/c1111027376256/',
        '北苑家园绣菊园': 'http://bj.lianjia.com/fangjia/c1111027376258/',
        '北苑家园莲葩园': 'http://bj.lianjia.com/fangjia/c1111027376254/',
        '北苑家园紫绶园': 'http://bj.lianjia.com/fangjia/c1111027376260/',
        '北苑家园绣菊园南区': 'http://bj.lianjia.com/fangjia/c1111027376259/',
        '世安家园': 'http://bj.lianjia.com/fangjia/c1111027379082/',
    }

districts = {'海淀': 'http://bj.lianjia.com/fangjia/haidian',
        '昌平': 'http://bj.lianjia.com/fangjia/changping',
        '朝阳': 'http://bj.lianjia.com/fangjia/chaoyang',
        '东城': 'http://bj.lianjia.com/fangjia/dongcheng',
        '西城': 'http://bj.lianjia.com/fangjia/xicheng',
    }

areas = {'西二旗': 'http://bj.lianjia.com/fangjia/xierqi1',
        '西三旗': 'http://bj.lianjia.com/fangjia/xisanqi1',
        '西北旺': 'http://bj.lianjia.com/fangjia/xibeiwang',
        '马连洼': 'http://bj.lianjia.com/fangjia/malianwa',
        '清河': 'http://bj.lianjia.com/fangjia/qinghe11',
        '安宁庄': 'http://bj.lianjia.com/fangjia/anningzhuang1',
        '回龙观': 'http://bj.lianjia.com/fangjia/huilongguan2',
        '天通苑': 'http://bj.lianjia.com/fangjia/tiantongyuan1',
        '北苑': 'http://bj.lianjia.com/fangjia/beiyuan2/',
        '望京': 'http://bj.lianjia.com/fangjia/wangjing',
        '立水桥': 'http://bj.lianjia.com/fangjia/lishuiqiao1/',
    }


def default_func():
    username = '18610292604' #'ur_user_name_here'
    cookie_file = 'weibo_login_cookies.dat'

    ts = datetime.datetime.now()
    format_time = ts.strftime("%Y-%m-%d %H:%M\t")
    #print format_time

    #unit test
    '''department = '东辰小区'
    url = 'http://bj.lianjia.com/fangjia/c1111027376788/'
    res = handle_lianjia(url)
    with open('dept/'+department, 'a') as f:
        f.write(format_time+res)
    print department, res
    exit(0) '''
    
    city_res = {}
    for city,url in cities.items():
        print city
        res = handle_lianjia(url)
        city_res[city] = res
        print format_time+res
        time.sleep(1.0)

    dept_res = {}
    for department,url in departments.items():
        print department
        res = handle_lianjia(url)
        dept_res[department] = res
        print format_time+res
        time.sleep(1.0)

    dist_res = {}
    for district,url in districts.items():
        print district
        res = handle_lianjia(url)
        dist_res[district] = res
        print format_time+res
        time.sleep(1.0)

    area_res = {}
    for area,url in areas.items():
        print area
        res = handle_lianjia(url)
        area_res[area] = res
        print format_time+res
        time.sleep(1.0)

    for city,res in city_res.items():
        with open('city/'+city, 'a') as f:
            f.write(format_time+res)

    for department,res in dept_res.items():
        with open('dept/'+department, 'a') as f:
            f.write(format_time+res)

    for district,res in dist_res.items():
        with open('dist/'+district, 'a') as f:
            f.write(format_time+res)

    for area,res in area_res.items():
        with open('area/'+area, 'a') as f:
            f.write(format_time+res)


def get_wangqian():

    url = 'http://210.75.213.188/shh/portal/bjjs/index.aspx'
    res = handle_wangqian(url)
    with open('wangqian/北京', 'a') as f:
        print '北京网签'+res
        f.write(res)


def delete_last_line(filename):
    file = open(filename, 'r+')
    file.seek(0, os.SEEK_END)
    pos = file.tell() - 1
    while pos > 0 and file.read(1) != "\n":
        pos -= 1
        file.seek(pos, os.SEEK_SET)
    if pos > 0:
        file.seek(pos + 1, os.SEEK_SET) #skip last \n
        file.truncate()
    file.close()


def revert_func():
    for city,url in cities.items():
        delete_last_line('city/'+city)

    for department,url in departments.items():
        delete_last_line('dept/'+department)

    for district,url in districts.items():
        delete_last_line('dist/'+district)

    for area,res in areas.items():
        delete_last_line('area/'+area)


if __name__ == '__main__':
    reload(sys)
    sys.setdefaultencoding('utf-8')
#    switch={
#        'revert': revert_func,
#        'default': default_func
#    }
#    switch[sys.argv[1]]()
    with open('RecipeExtractionData.tsv') as f:
        lines = f.readlines()

    pat_num = re.compile(u'(^|\\b|\s|/|\(|\-)(\d*(½|⅓|⅔|¼|¾|⅕|⅖|⅗|⅘|⅙|⅚|⅛|⅜|⅝|⅞)|\d+\.\d+%?|\d+/\d+|\d+%?-\d+%?|\d+%? to \d+%?|\d+%?)', re.M)
    pat_punc = re.compile(r'(,|/|\(|\)|\-)')

    rows = [line.rstrip('\n').split('\t') for line in lines]
    lines = []

    quantifiers = {}
    for row in rows:
        sentences = json.loads(row[1])
        if len(sentences) == 0:
            continue
        for sentence in sentences:
            if not sentence or sentence == '':
                continue
            sentence = sentence.lower()
            sentence = pat_num.sub(' N ', sentence)
            sentence = pat_punc.sub(' \\1 ', sentence)
            words = sentence.split()
            lines.append(words)
            num_occur = False
            for word in words:
                #print '[%s]' % (word),
                if word.startswith('N'):
                    num_occur = True
                else:
                    if num_occur:
                        #print '!!!',
                        quantifiers[word] = quantifiers.get(word, 0) + 1
                        num_occur = False
        #print

    #TOP
#    sorted_quantifiers = sorted(quantifiers.items(), key=operator.itemgetter(1), reverse=True)
#    for quantifier in sorted_quantifiers:
#        print '%s\t%d' % (quantifier[0], quantifier[1])

    #ENTROPY
    quantifiers_prevs = {}
    for sentence in lines:
        prev_word = 'HEAD'
        for word in sentence:
            if word in quantifiers:
                if word in quantifiers_prevs:
                    quantifiers_prevs[word][prev_word] = quantifiers_prevs[word].get(prev_word, 0) + 1
                else:
                    quantifiers_prevs[word] = {}
                    quantifiers_prevs[word][prev_word] = 1
            prev_word = word

    quantifier_entropy = {}
    for quantifier, prevs in quantifiers_prevs.items():
        total = 0
        for prev, count in prevs.items():
            total += count
        if total <= 1:
            continue

        print quantifier,
        entropy = 0.0
        for prev, count in prevs.items():
            p = count*1.0/total
            entropy += p * math.log(p,2)
            print '[%s:%d:%f]' % (prev, count, p),
        quantifier_entropy[quantifier] = -entropy
        print -entropy

    sorted_quantifiers = sorted(quantifier_entropy.items(), key=operator.itemgetter(1), reverse=True)
    for quantifier in sorted_quantifiers:
        print '%s\t%f' % (quantifier[0], quantifier[1])

#    document = '3 cups of coffee. 4 o.z buzz. 1/2cup soy sauce'
#    sentences = nltk.sent_tokenize(document)
#    sentences = [nltk.word_tokenize(sent) for sent in sentences]
#    print sentences
#    sentences = [nltk.pos_tag(sent) for sent in sentences]
#    print sentences
